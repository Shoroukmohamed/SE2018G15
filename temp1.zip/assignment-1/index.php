<?php include_once('./controllers/common.php') ?>
<?php include_once('./components/head.php') ?>

    <h1 class="mt-5">School Information System</h1>
    <p class="lead">Manage school information like students, course and grades</code>.</p>

<?php include_once('./components/tail.php') ?>